event entity @s minecraft:default_player
give @s item:berubah_bima 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
give @s item:unjb
effect @s clear
clear @s item:unb
clear @s item:helios_bima