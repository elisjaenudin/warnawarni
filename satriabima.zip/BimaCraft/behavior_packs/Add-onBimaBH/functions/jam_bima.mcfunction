clear @s[tag=Jam_bima,tag=stone_merah] item:bima
clear @s[tag=Jam_bima,tag=stone_biru] item:stone_biru
clear @s[tag=Jam_bima,tag=stone_hijau] item:stone_hijau
clear @s[tag=Jam_bima,tag=stone_ungu] item:stone_ungu
clear @s[tag=Jam_bima,tag=stone_hitam] item:stone_hitam
give @s[tag=Jam_bima,tag=stone_merah] item:bima 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
give @s[tag=Jam_bima,tag=stone_biru] item:stone_biru 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
give @s[tag=Jam_bima,tag=stone_hijau] item:stone_hijau 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
give @s[tag=Jam_bima,tag=stone_ungu] item:stone_ungu 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
give @s[tag=Jam_bima,tag=stone_hitam] item:stone_hitam 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
give @s[tag=Jam_bima,tag=red_stone] item:unjb
clear @s[tag=Jam_bima] item:changer_azazel
clear @s[tag=Jam_bima] item:changer_bima
clear @s[tag=Jam_bima] item:berubah_torga
clear @s[tag=Jam_bima] item:torga_ice
clear @s[tag=Jam_bima] item:lonceng_hensin
clear @s[tag=red_stone,tag=Jam_bima] item:jam_bima