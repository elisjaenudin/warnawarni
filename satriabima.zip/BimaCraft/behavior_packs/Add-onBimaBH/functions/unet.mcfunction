event entity @s minecraft:default_player
effect @s clear
clear @s item:bima
clear @s item:stone_biru
clear @s item:stone_hijau
clear @s item:berubah_torga
give @s item:evil_torga 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
clear @s item:torga_ice
clear @s item:helios
clear @s item:unet