effect @s clear
clear @s[tag=stone_merah] item:bima
clear @s item:stone_biru
clear @s item:stone_hijau
clear @s item:stone_ungu
clear @s item:stone_hitam
give @s[tag=stone_merah] item:bima 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
give @s[tag=stone_biru] item:stone_biru 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
give @s[tag=stone_hijau] item:stone_hijau 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
give @s[tag=stone_ungu] item:stone_ungu 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
give @s[tag=stone_hitam] item:stone_hitam 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
clear @s item:helios_earth
clear @s item:taranis
clear @s item:helios
clear @s item:un