give @s[tag=Bima] item:berubah_bima 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
give @s[tag=Bima] item:unjb
clear @s[tag=Bima] item:jam_bima
clear @s[tag=Bima] item:changer_azazel
clear @s[tag=Bima] item:berubah_torga
clear @s[tag=Bima] item:torga_ice
clear @s[tag=Bima] item:lonceng_hensin
clear @s[tag=red_stone,tag=Bima] item:changer_bima