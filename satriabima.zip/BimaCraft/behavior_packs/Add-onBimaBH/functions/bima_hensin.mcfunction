give @s[tag=Bima] item:unb 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
give @s[tag=Bima] item:helios_bima 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
clear @s item:unjb
clear @s item:berubah_bima
