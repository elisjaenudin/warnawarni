event entity @s[tag=Jam_bima] minecraft:delay_storm
clear @s item:un
give @s[tag=red_stone,tag=Jam_bima] item:un 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
clear @s[tag=Jam_bima,tag=stone_merah] item:bima
give @s[tag=Jam_bima,tag=stone_merah] item:bima 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
clear @s[tag=Jam_bima,tag=stone_hijau] item:stone_hijau
give @s[tag=Jam_bima,tag=stone_hijau] item:stone_hijau 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
clear @s[tag=Jam_bima,tag=stone_ungu] item:stone_ungu
give @s[tag=Jam_bima,tag=stone_ungu] item:stone_ungu 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
clear @s item:helios_earth
clear @s item:helios
clear @s item:taranis
clear @s[tag=Jam_bima] item:stone_biru
clear @s item:unjb