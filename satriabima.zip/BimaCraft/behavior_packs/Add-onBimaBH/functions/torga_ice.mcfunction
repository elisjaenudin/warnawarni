give @s[tag=ice_stone,tag=thunder_stone] item:berubah_torga 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
effect @s clear
clear @s item:unt
give @s[tag=ice_stone]item:unt 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
clear @s[tag=ice_stone] item:torga_ice

