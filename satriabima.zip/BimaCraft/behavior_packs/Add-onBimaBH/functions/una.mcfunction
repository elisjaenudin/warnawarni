event entity @s minecraft:default_player
give @s item:berubah 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
give @s item:unjb
clear @s item:taranis
effect @s clear
clear @s item:una