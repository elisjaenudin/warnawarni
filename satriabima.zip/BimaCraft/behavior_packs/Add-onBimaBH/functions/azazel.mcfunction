give @s[tag=dark_stone,tag=Azazel] item:una 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
give @s[tag=dark_stone,tag=Azazel] item:taranis 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
clear @s item:unjb
clear @s item:berubah
