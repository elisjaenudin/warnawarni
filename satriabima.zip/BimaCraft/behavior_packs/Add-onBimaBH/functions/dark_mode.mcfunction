
clear @s item:un
give @s[tag=Jam_bima] item:un 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
clear @s item:unjb
clear @s item:helios_earth
clear @s item:helios
give @s[tag=Jam_bima] item:helios 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
clear @s item:taranis
give @s[tag=Jam_bima] item:taranis 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
clear @s[tag=Jam_bima] item:stone_hitam