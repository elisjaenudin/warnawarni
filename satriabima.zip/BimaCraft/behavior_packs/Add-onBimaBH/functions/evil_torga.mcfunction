effect @s clear
clear @s item:unt
give @s item:unet 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
clear @s item:berubah_torga
clear @s item:evil_torga
clear @s item:berubah
clear @s item:berubah_bima
clear @s item:bima
clear @s item:lonceng_hensin
clear @s item:stone_biru
clear @s item:stone_hijau
clear @s item:torga_ice