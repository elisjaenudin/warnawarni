give @s[tag=ice_stone] item:torga_ice 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
effect @s clear
clear @s item:unt
give @s[tag=thunder_stone] item:unt 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
clear @s[tag=thunder_stone] item:berubah_torga
clear @s[tag=thunder_stone] item:berubah_bima
clear @s[tag=thunder_stone] item:bima
clear @s item:lonceng_hensin
clear @s item:stone_biru
clear @s item:stone_hijau