event entity @s minecraft:default_player
effect @s clear
clear @s item:helios_bima
clear @s item:bima
clear @s item:stone_biru
clear @s item:stone_hijau
clear @s item:berubah_torga
clear @s item:unbl
clear @s item:lonceng
give @s item:lonceng 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
clear @s item:torga_ice
give @s item:lonceng_hensin 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
clear @s item:helios