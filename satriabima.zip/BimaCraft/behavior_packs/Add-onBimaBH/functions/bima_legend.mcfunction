effect @s clear
give @s[tag=red_stone] item:helios_bima
clear @s[tag=red_stone] item:lonceng_hensin
clear @s item:lonceng
give @s[tag=Bima_legend] item:lonceng 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
clear @s item:unbl
give @s[tag=Bima_legend] item:unbl 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
clear @s item:berubah_torga
clear @s item:evil_torga
clear @s item:berubah
clear @s item:berubah_bima
clear @s item:bima
clear @s item:stone_biru
clear @s item:stone_hijau
clear @s item:torga_ice
clear @s item:stone_hitam
clear @s item:jam_bima