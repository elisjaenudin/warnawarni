give @s[tag=dark_stone,tag=Azazel] item:berubah 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
give @s[tag=Azazel] item:unjb
clear @s[tag=Azazel] item:changer_bima
clear @s[tag=Azazel] item:berubah_torga
clear @s[tag=Azazel] item:torga_ice
clear @s[tag=Azazel] item:jam_bima
clear @s[tag=dark_stone,tag=Azazel] item:changer_azazel