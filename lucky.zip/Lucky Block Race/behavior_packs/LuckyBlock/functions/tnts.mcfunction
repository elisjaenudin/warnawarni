execute @p[r=8,c=1] ~ ~ ~ fill ~1 ~-1 ~1 ~-1 ~-1 ~-1 tnt
execute @p[r=8,c=1] ~ ~ ~ setblock ~ ~-1 ~ concrete 14
execute @p[r=8,c=1] ~ ~ ~ fill ~1 ~ ~1 ~-1 ~ ~-1 heavy_weighted_pressure_plate
execute @p[r=8,c=1] ~ ~ ~ setblock ~ ~ ~ air 0