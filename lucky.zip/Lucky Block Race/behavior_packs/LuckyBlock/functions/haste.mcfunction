effect @p[r=8,c=1] haste 128 6 true
particle minecraft:totem_particle ~ ~1 ~