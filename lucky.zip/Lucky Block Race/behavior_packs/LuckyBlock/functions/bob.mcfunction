replaceitem entity @e[type=zombie,name=§l§eBob] slot.armor.chest 0 diamond_chestplate
replaceitem entity @e[type=zombie,name=§l§eBob] slot.armor.feet 0 diamond_boots
replaceitem entity @e[type=zombie,name=§l§eBob] slot.armor.head 0 diamond_helmet
replaceitem entity @e[type=zombie,name=§l§eBob] slot.armor.legs 0 diamond_leggings
replaceitem entity @e[type=zombie,name=§l§eBob] slot.weapon.mainhand 0 diamond_sword
effect @e[type=zombie,name=§l§eBob] resistance 1999 2 true
effect @e[type=zombie,name=§l§eBob] strength 1999 2 true
effect @e[type=zombie,name=§l§eBob] speed 1999 0 true