fill ~2 ~ ~2 ~-2 ~ ~-2 bookshelf
fill ~1 ~ ~1 ~-1 ~ ~-1 air
setblock ~ ~ ~ enchanting_table