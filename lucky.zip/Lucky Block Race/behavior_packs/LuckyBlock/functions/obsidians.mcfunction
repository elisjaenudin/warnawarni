execute @p[r=8,c=1] ~ ~ ~ fill ~1 ~2 ~1 ~-1 ~ ~-1 obsidian 0 hollow
execute @p[r=8,c=1] ~ ~ ~ fill ~ ~ ~ ~ ~1 ~ air 0
execute @p[r=8,c=1] ~ ~ ~ setblock ~ ~1 ~1 glass
execute @p[r=8,c=1] ~ ~ ~ setblock ~ ~1 ~-1 glass
execute @p[r=8,c=1] ~ ~ ~ setblock ~1 ~1 ~ glass
execute @p[r=8,c=1] ~ ~ ~ setblock ~-1 ~1 ~ glass
execute @p[r=8,c=1] ~ ~ ~ setblock ~ ~1 ~ flowing_water
execute @p[r=8,c=1] ~ ~ ~ setblock ~ ~ ~ flowing_water
