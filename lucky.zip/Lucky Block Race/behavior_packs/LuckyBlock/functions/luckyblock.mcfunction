execute @e[type=item,name=luckyblock] ~ ~4 ~ fill ~4 ~-4 ~4 ~-3 ~3 ~-3 concrete 1
execute @e[type=item,name=luckyblock] ~ ~4 ~ fill ~3 ~-3 ~-3 ~-2 ~2 ~-3 air
execute @e[type=item,name=luckyblock] ~ ~4 ~ fill ~-2 ~-3 ~4 ~3 ~2 ~4 air
execute @e[type=item,name=luckyblock] ~ ~4 ~ fill ~-3 ~-3 ~3 ~-3 ~2 ~-2 air
execute @e[type=item,name=luckyblock] ~ ~4 ~ fill ~4 ~-3 ~-2 ~4 ~2 ~3 air
execute @e[type=item,name=luckyblock] ~ ~4 ~ fill ~3 ~3 ~3 ~-2 ~3 ~-2 air
execute @e[type=item,name=luckyblock] ~ ~4 ~ fill ~3 ~-4 ~3 ~-2 ~-4 ~-2 air
execute @e[type=item,name=luckyblock] ~ ~4 ~ fill ~3 ~-3 ~3 ~-2 ~2 ~-2 concrete 4

execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~3 ~2 ~-3 concrete
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~3 ~-3 ~-3 concrete
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~-2 ~2 ~-3 concrete
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~-2 ~-3 ~-3 concrete

execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~4 ~-3 ~3 concrete
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~4 ~-3 ~-2 concrete
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~4 ~2 ~3 concrete
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~4 ~2 ~-2 concrete

execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~-2 ~-3 ~4 concrete
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~3 ~-3 ~4 concrete
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~-2 ~2 ~4 concrete
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~3 ~2 ~4 concrete

execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~-3 ~-3 ~-2 concrete
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~-3 ~-3 ~3 concrete
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~-3 ~2 ~-2 concrete
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~-3 ~2 ~3 concrete

execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~ ~-3 ~-3 concrete
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~1 ~-3 ~4 concrete 
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~-3 ~-3 ~1 concrete 
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~4 ~-3 ~ concrete 

execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~ ~-1 ~-3 concrete
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~1 ~-1 ~4 concrete
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~-3 ~-1 ~1 concrete
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~4 ~-1 ~ concrete

execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~-1 ~ ~-3 concrete
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~ ~1 ~-3 concrete
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~1 ~1 ~-3 concrete
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~2 ~ ~-3 concrete

execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~2 ~ ~4 concrete
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~1 ~1 ~4 concrete
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~ ~1 ~4 concrete
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~-1 ~ ~4 concrete

execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~4 ~ ~-1 concrete
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~4 ~1 ~ concrete
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~4 ~1 ~1 concrete
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~4 ~ ~2 concrete

execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~-3 ~ ~2 concrete
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~-3 ~1 ~1 concrete
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~-3 ~1 ~ concrete
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~-3 ~ ~-1 concrete

execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~ ~-1 ~-2 dispenser 3
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~1 ~-1 ~3 dispenser 2
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~-2 ~-1 ~1 dispenser 5
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~3 ~-1 ~ dispenser 4

execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~ ~-1 ~-1 air
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~1 ~-1 ~2 air
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~-1 ~-1 ~1 air
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~2 ~-1 ~ air

execute @e[type=item,name=luckyblock] ~ ~4 ~ replaceitem block ~ ~-1 ~-2 slot.container 0 lucky:luckyblockf
execute @e[type=item,name=luckyblock] ~ ~4 ~ replaceitem block ~1 ~-1 ~3 slot.container 0 lucky:luckyblockf
execute @e[type=item,name=luckyblock] ~ ~4 ~ replaceitem block ~-2 ~-1 ~1 slot.container 0 lucky:luckyblockf
execute @e[type=item,name=luckyblock] ~ ~4 ~ replaceitem block ~3 ~-1 ~ slot.container 0 lucky:luckyblockf

execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~ ~-2 ~-3 stone_button 2
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~1 ~-2 ~4 stone_button 3
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~-3 ~-2 ~1 stone_button 4
execute @e[type=item,name=luckyblock] ~ ~4 ~ setblock ~4 ~-2 ~ stone_button 5

