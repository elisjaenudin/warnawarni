execute @p[r=8,c=1] ~ ~ ~ fill ~2 ~ ~2 ~-2 ~3 ~-2 grass
execute @p[r=8,c=1] ~ ~ ~ fill ~ ~ ~ ~ ~2 ~1 air
execute @p[r=8,c=1] ~ ~ ~ setblock ~ ~ ~ bed 14
execute @p[r=8,c=1] ~ ~ ~ fill ~2 ~1 ~2 ~-2 ~3 ~2 air
execute @p[r=8,c=1] ~ ~ ~ fill ~-2 ~1 ~-2 ~2 ~3 ~-2 air
execute @p[r=8,c=1] ~ ~ ~ fill ~2 ~1 ~-1 ~2 ~3 ~1 air 0
execute @p[r=8,c=1] ~ ~ ~ fill ~-2 ~1 ~1 ~-2 ~3 ~-1 air 0
execute @p[r=8,c=1] ~ ~ ~ setblock ~1 ~1 ~ anvil
execute @p[r=8,c=1] ~ ~ ~ setblock ~1 ~1 ~1 furnace 1
execute @p[r=8,c=1] ~ ~ ~ setblock ~-1 ~1 ~1 crafting_table
execute @p[r=8,c=1] ~ ~ ~ setblock ~-1 ~1 ~ barrel 5
execute @p[r=8,c=1] ~ ~ ~ setblock ~ ~1 ~2 wooden_door 1
execute @p[r=8,c=1] ~ ~ ~ setblock ~ ~2 ~-1 stained_glass_pane 13
execute @p[r=8,c=1] ~ ~ ~ setblock ~1 ~2 ~ stained_glass_pane 13
execute @p[r=8,c=1] ~ ~ ~ setblock ~-1 ~2 ~ stained_glass_pane 13
execute @p[r=8,c=1] ~ ~ ~ fill ~-2 ~ ~-2 ~-2 ~ ~-2 air
execute @p[r=8,c=1] ~ ~ ~ fill ~2 ~ ~2 ~2 ~ ~2 air
execute @p[r=8,c=1] ~ ~ ~ fill ~-2 ~ ~2 ~-2 ~ ~2 air
execute @p[r=8,c=1] ~ ~ ~ fill ~2 ~ ~-2 ~2 ~ ~-2 air
execute @p[r=8,c=1] ~ ~ ~ setblock ~ ~1 ~-2 grass
execute @p[r=8,c=1] ~ ~ ~ fill ~1 ~1 ~-2 ~1 ~2 ~-2 grass
execute @p[r=8,c=1] ~ ~ ~ setblock ~2 ~1 ~ grass
execute @p[r=8,c=1] ~ ~ ~ setblock ~-2 ~1 ~ grass
execute @p[r=8,c=1] ~ ~ ~ setblock ~-1 ~1 ~2 double_plant 2
execute @p[r=8,c=1] ~ ~ ~ setblock ~-1 ~4 ~1 double_plant 3
execute @p[r=8,c=1] ~ ~ ~ setblock ~2 ~2 ~ tallgrass
execute @p[r=8,c=1] ~ ~ ~ setblock ~ ~2 ~-2 tallgrass
execute @p[r=8,c=1] ~ ~ ~ setblock ~-2 ~2 ~ yellow_flower 
execute @p[r=8,c=1] ~ ~ ~ setblock ~ ~4 ~ yellow_flower
execute @p[r=8,c=1] ~ ~ ~ setblock ~ ~4 ~-1 tallgrass
execute @p[r=8,c=1] ~ ~ ~ setblock ~1 ~4 ~-1 tallgrass
