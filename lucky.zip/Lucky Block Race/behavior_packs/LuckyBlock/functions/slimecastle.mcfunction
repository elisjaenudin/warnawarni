execute @p[r=8,c=1] ~ ~ ~ fill ~2 ~-1 ~2 ~-2 ~2 ~-2 slime
execute @p[r=8,c=1] ~ ~ ~ fill ~1 ~ ~1 ~-1 ~3 ~-1 air
execute @p[r=8,c=1] ~ ~ ~ fill ~-2 ~ ~ ~-2 ~1 ~ air 0
execute @p[r=8,c=1] ~ ~ ~ fill ~2 ~ ~ ~2 ~1 ~ air 0
execute @p[r=8,c=1] ~ ~ ~ fill ~ ~ ~-2 ~ ~1 ~-2 air 0
execute @p[r=8,c=1] ~ ~ ~ fill ~ ~ ~2 ~ ~1 ~2 air 0
execute @p[r=8,c=1] ~ ~ ~ fill ~-2 ~3 ~-2 ~-2 ~3 ~-2 slime
execute @p[r=8,c=1] ~ ~ ~ fill ~2 ~3 ~2 ~2 ~3 ~2 slime
execute @p[r=8,c=1] ~ ~ ~ fill ~-2 ~3 ~2 ~-2 ~3 ~2 slime
execute @p[r=8,c=1] ~ ~ ~ fill ~2 ~3 ~-2 ~2 ~3 ~-2 slime
execute @p[r=8,c=1] ~ ~ ~ setblock ~2 ~3 ~ slime
execute @p[r=8,c=1] ~ ~ ~ setblock ~-2 ~3 ~ slime
execute @p[r=8,c=1] ~ ~ ~ setblock ~ ~3 ~2 slime
execute @p[r=8,c=1] ~ ~ ~ setblock ~ ~3 ~-2 slime