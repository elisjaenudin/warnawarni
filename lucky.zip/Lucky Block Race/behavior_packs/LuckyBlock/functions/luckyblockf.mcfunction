scoreboard players add @e[type=item,name=luckyblockf] Lucky 1
execute @a ~ ~ ~ detect ~ ~1 ~ concrete 0 spreadplayers ~ ~ 6 8 @p 
execute @a ~ ~ ~ detect ~ ~1 ~ concrete 4 spreadplayers ~ ~ 6 8 @p 
execute @a ~ ~ ~ detect ~ ~1 ~ concrete 1 spreadplayers ~ ~ 6 8 @p 
execute @a ~ ~ ~ detect ~ ~ ~ concrete 0 spreadplayers ~ ~ 6 8 @p 
execute @a ~ ~ ~ detect ~ ~ ~ concrete 4 spreadplayers ~ ~ 6 8 @p 
execute @a ~ ~ ~ detect ~ ~ ~ concrete 1 spreadplayers ~ ~ 6 8 @p 
execute @e[type=item,name=luckyblockf,scores={Lucky=70}] ~ ~ ~ function lbff
execute @e[type=item,name=luckyblockf,scores={Lucky=80}] ~ ~ ~ function lbfd
execute @e[type=item,name=luckyblockf,scores={Lucky=100}] ~ ~ ~ function lbfd
execute @e[type=item,name=luckyblockf] ~ ~ ~ detect ~ ~1 ~ air 0 kill @s
execute @e[type=item,name=luckyblockf] ~ ~ ~ fill ~5 ~-5 ~5 ~-5 ~5 ~-5 stained_glass 4 replace concrete 4
execute @e[type=item,name=luckyblockf] ~ ~ ~ fill ~5 ~-5 ~5 ~-5 ~5 ~-5 stained_glass 1 replace concrete 1
execute @e[type=item,name=luckyblockf] ~ ~ ~ fill ~5 ~-5 ~5 ~-5 ~5 ~-5 stained_glass 0 replace concrete 0
execute @e[type=item,name=luckyblockf] ~ ~ ~ fill ~5 ~-5 ~5 ~-5 ~5 ~-5 stained_glass 0 replace dispenser
execute @e[type=item,name=luckyblockf] ~ ~ ~ fill ~5 ~-5 ~5 ~-5 ~5 ~-5 air 0 replace stone_button
execute @e[type=item,name=luckyblockf] ~ ~ ~ setblock ~ ~ ~-1 stained_glass 0
execute @e[type=item,name=luckyblockf] ~ ~ ~ setblock ~1 ~ ~2 stained_glass 0
execute @e[type=item,name=luckyblockf] ~ ~ ~ setblock ~-1 ~ ~1 stained_glass 0
execute @e[type=item,name=luckyblockf] ~ ~ ~ setblock ~2 ~ ~ stained_glass 0