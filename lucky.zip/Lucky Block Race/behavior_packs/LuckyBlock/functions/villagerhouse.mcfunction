fill ~2 ~2 ~2 ~-2 ~4 ~-2 planks 0 hollow
fill ~1 ~2 ~1 ~-1 ~4 ~-1 air
fill ~2 ~ ~2 ~-2 ~1 ~-2 cobblestone
fill ~2 ~5 ~2 ~-2 ~5 ~-2 log
fill ~2 ~6 ~2 ~-2 ~6 ~-2 fence
fill ~1 ~6 ~1 ~-1 ~6 ~-1 air
fill ~1 ~2 ~-1 ~1 ~5 ~-1 ladder 
fill ~-2 ~2 ~-2 ~-2 ~4 ~-2 log
fill ~2 ~2 ~2 ~2 ~4 ~2 log
fill ~-2 ~2 ~2 ~-2 ~4 ~2 log
fill ~2 ~2 ~-2 ~2 ~4 ~-2 log
setblock ~2 ~3 ~ stained_glass_pane
setblock ~-2 ~3 ~ stained_glass_pane
setblock ~ ~3 ~-2 stained_glass_pane
setblock ~ ~2 ~2 wooden_door 3
setblock ~1 ~2 ~-1 effect99:lucky_drops
setblock ~-1 ~2 ~-1 fence
setblock ~-1 ~3 ~-1 wooden_pressure_plate
setblock ~-1 ~2 ~ spruce_stairs 2 
summon villager ~ ~2 ~
summon villager ~ ~2 ~