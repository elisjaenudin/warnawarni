execute @p[r=8,c=1] ~ ~ ~ fill ~1 ~ ~1 ~-1 ~3 ~-1 iron_bars 0 hollow
execute @p[r=8,c=1] ~ ~ ~ fill ~ ~ ~ ~ ~3 ~ air 0
execute @p[r=8,c=1] ~ ~ ~ fill ~ ~29 ~ ~ ~30 ~ anvil