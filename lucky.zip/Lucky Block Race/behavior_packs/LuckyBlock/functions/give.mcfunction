give @p effect99:lucky_block 64 
give @p effect99:good_luck_block 64
give @p effect99:unlucky_block 64
give @p effect99:withered_lucky_block 64
give @p effect99:lucky_mobs 64
give @p effect99:lucky_drops 64
give @p effect99:lucky_structures 64