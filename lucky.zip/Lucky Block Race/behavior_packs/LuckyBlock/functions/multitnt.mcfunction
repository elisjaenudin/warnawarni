tellraw @p {"rawtext":[{"text":"§4Your death wish came true!"}]}
summon tnt ~2 ~15 ~
summon tnt ~-2 ~15 ~
summon tnt ~ ~15 ~2
summon tnt ~ ~15 ~-2
summon tnt ~2 ~15 ~2
summon tnt ~2 ~15 ~-2
summon tnt ~-2 ~15 ~2
summon tnt ~-2 ~15 ~-2
summon tnt ~4 ~15 ~
summon tnt ~-4 ~15 ~
summon tnt ~ ~15 ~4
summon tnt ~ ~15 ~-4
summon tnt ~4 ~15 ~4
summon tnt ~4 ~15 ~-4
summon tnt ~-4 ~15 ~4
summon tnt ~-4 ~15 ~-4