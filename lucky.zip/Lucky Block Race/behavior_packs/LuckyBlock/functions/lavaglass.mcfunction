execute @p[r=8,c=1] ~ ~ ~ fill ~1 ~ ~1 ~-1 ~6 ~-1 stained_glass 7
execute @p[r=8,c=1] ~ ~ ~ fill ~ ~ ~ ~ ~5 ~ air
execute @p[r=8,c=1] ~ ~ ~ setblock ~ ~6 ~ flowing_lava