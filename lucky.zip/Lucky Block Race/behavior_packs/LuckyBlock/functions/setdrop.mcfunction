fill ~1 ~ ~1 ~-1 ~1 ~-1 air 0 replace water
setblock ~ ~ ~ beacon
setblock ~ ~4 ~ air 0
setblock ~ ~16 ~ effect99:setdrop
setblock ~ ~16 ~ air 0 destroy
summon fireworks_rocket ~ ~4 ~ 