execute @p[r=8,c=1] ~ ~ ~ fill ~1 ~ ~1 ~-1 ~4 ~-1 iron_bars 0 hollow
execute @p[r=8,c=1] ~ ~ ~ fill ~ ~ ~ ~ ~4 ~ air 0
execute @p[r=8,c=1] ~ ~ ~ fill ~ ~4 ~ ~ ~4 ~ flowing_lava