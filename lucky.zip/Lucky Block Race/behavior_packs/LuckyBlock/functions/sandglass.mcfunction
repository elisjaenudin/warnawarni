execute @p[r=8,c=1] ~ ~ ~ fill ~1 ~ ~1 ~-1 ~5 ~-1 stained_glass 1
execute @p[r=8,c=1] ~ ~ ~ fill ~ ~ ~ ~ ~5 ~ air
execute @p[r=8,c=1] ~ ~ ~ setblock ~ ~ ~ fire
execute @p[r=8,c=1] ~ ~ ~ fill ~ ~40 ~ ~ ~45 ~ concretepowder 1