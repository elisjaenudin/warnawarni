execute @p[r=8,c=1] ~ ~ ~ fill ~2 ~ ~2 ~-2 ~ ~-2 fire
execute @p[r=8,c=1] ~ ~ ~ fill ~1 ~ ~1 ~-1 ~ ~-1 air 0