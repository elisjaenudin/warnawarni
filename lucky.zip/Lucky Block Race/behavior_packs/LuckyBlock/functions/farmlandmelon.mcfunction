fill ~2 ~-1 ~2 ~-2 ~-1 ~-2 farmland
fill ~2 ~ ~2 ~-2 ~ ~-2 melon_stem 0 replace air
setblock ~ ~-1 ~ water
setblock ~-1 ~ ~ melon_block
setblock ~-1 ~ ~-2 melon_block
setblock ~-1 ~ ~2 melon_block
setblock ~-2 ~ ~2 melon_block
setblock ~1 ~ ~-1 melon_block
setblock ~2 ~ ~-1 melon_block
setblock ~2 ~ ~1 melon_block