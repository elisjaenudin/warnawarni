summon lucky:s_explode ~ ~2.5 ~
kill @e[type=lucky:giantblock,r=15]