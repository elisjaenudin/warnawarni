summon lucky:giantblock meteor2 ~-35 ~40 ~35
title @p subtitle §l§gMeteor Alert
title @p title §l