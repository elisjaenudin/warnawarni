fill ~2 ~ ~2 ~-2 ~ ~-2 end_stone
fill ~-2 ~ ~-2 ~-2 ~ ~-2 air
fill ~2 ~ ~2 ~2 ~ ~2 air
fill ~-2 ~ ~2 ~-2 ~ ~2 air
fill ~2 ~ ~-2 ~2 ~ ~-2 air
fill ~ ~1 ~ ~ ~4 ~ chorus_plant
fill ~1 ~4 ~ ~1 ~5 ~ chorus_plant
fill ~-1 ~4 ~ ~-1 ~6 ~ chorus_plant
setblock ~1 ~6 ~ chorus_flower
setblock ~-1 ~7 ~ chorus_flower