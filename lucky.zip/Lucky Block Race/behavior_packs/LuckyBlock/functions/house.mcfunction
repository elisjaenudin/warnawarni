execute @p[r=8,c=1] ~ ~ ~ fill ~2 ~2 ~2 ~-2 ~4 ~-2 planks 0 hollow
execute @p[r=8,c=1] ~ ~ ~ fill ~1 ~2 ~1 ~-1 ~4 ~-1 air
execute @p[r=8,c=1] ~ ~ ~ fill ~2 ~ ~2 ~-2 ~1 ~-2 cobblestone
execute @p[r=8,c=1] ~ ~ ~ fill ~2 ~5 ~2 ~-2 ~5 ~-2 log
execute @p[r=8,c=1] ~ ~ ~ fill ~-2 ~2 ~-2 ~-2 ~4 ~-2 log
execute @p[r=8,c=1] ~ ~ ~ fill ~2 ~2 ~2 ~2 ~4 ~2 log
execute @p[r=8,c=1] ~ ~ ~ fill ~-2 ~2 ~2 ~-2 ~4 ~2 log
execute @p[r=8,c=1] ~ ~ ~ fill ~2 ~2 ~-2 ~2 ~4 ~-2 log
execute @p[r=8,c=1] ~ ~ ~ fill ~-2 ~5 ~-2 ~-2 ~5 ~-2 air
execute @p[r=8,c=1] ~ ~ ~ fill ~2 ~5 ~2 ~2 ~5 ~2 air
execute @p[r=8,c=1] ~ ~ ~ fill ~-2 ~5 ~2 ~-2 ~5 ~2 air
execute @p[r=8,c=1] ~ ~ ~ fill ~2 ~5 ~-2 ~2 ~5 ~-2 air
execute @p[r=8,c=1] ~ ~ ~ setblock ~2 ~3 ~ stained_glass_pane
execute @p[r=8,c=1] ~ ~ ~ setblock ~-2 ~3 ~ stained_glass_pane
execute @p[r=8,c=1] ~ ~ ~ setblock ~ ~3 ~2 stained_glass_pane
execute @p[r=8,c=1] ~ ~ ~ fill ~ ~2 ~ ~ ~3 ~-2 air
execute @p[r=8,c=1] ~ ~ ~ setblock ~ ~2 ~-2 wooden_door 3
execute @p[r=8,c=1] ~ ~ ~ setblock ~1 ~2 ~-1 effect99:lucky_drops
execute @p[r=8,c=1] ~ ~ ~ setblock ~-1 ~2 ~-1 fence
execute @p[r=8,c=1] ~ ~ ~ setblock ~-1 ~3 ~-1 wooden_pressure_plate
execute @p[r=8,c=1] ~ ~ ~ setblock ~-1 ~2 ~ spruce_stairs 2 
execute @p[r=8,c=1] ~ ~ ~  tp @s ~ ~2 ~