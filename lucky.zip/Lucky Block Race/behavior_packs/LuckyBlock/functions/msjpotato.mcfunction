tellraw @p {"rawtext":[{"text":"§gYour wish came true! (If you like potatoes)"}]}
function setdrop_potato