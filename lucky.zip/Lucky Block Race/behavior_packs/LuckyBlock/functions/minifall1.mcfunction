execute @p[r=8,c=1] ~ ~ ~ fill ~1 ~-1 ~1 ~-1 ~-20 ~-1 air 0
execute @p[r=8,c=1] ~ ~ ~ fill ~1 ~-20 ~1 ~-1 ~-20 ~-1 lava 0
execute @p[r=8,c=1] ~ ~ ~ fill ~1 ~-19 ~1 ~-1 ~-19 ~-1 web 0