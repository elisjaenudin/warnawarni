effect @p[r=8,c=1] speed 25 15 true
particle minecraft:totem_particle ~ ~1 ~