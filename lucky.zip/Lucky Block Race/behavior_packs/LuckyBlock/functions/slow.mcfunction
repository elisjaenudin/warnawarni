effect @p[r=8,c=1] slowness 10 128 true
particle minecraft:knockback_roar_particle ~ ~1 ~