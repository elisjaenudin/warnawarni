setblock ~2 ~ ~2 effect99:setdrop_potato
setblock ~-2 ~ ~-2 effect99:setdrop_potato
setblock ~2 ~ ~-2 effect99:setdrop_potato
setblock ~-2 ~ ~2 effect99:setdrop_potato
setblock ~2 ~ ~2 air 0 destroy
setblock ~-2 ~ ~-2 air 0 destroy
setblock ~2 ~ ~-2 air 0 destroy
setblock ~-2 ~ ~2 air 0 destroy