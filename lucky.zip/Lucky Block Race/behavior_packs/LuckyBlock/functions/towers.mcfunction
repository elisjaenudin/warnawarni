execute @e[name=p1,type=pig] ~ ~0.9 ~ tp @e[name=p2,type=pig,r=11,c=1] ~ ~ ~
execute @e[name=p2,type=pig] ~ ~0.9 ~ tp @e[name=p3,type=pig,r=11,c=1] ~ ~ ~
execute @e[name=p3,type=pig] ~ ~0.9 ~ tp @e[name=p4,type=pig,r=11,c=1] ~ ~ ~
execute @e[name=p4,type=pig] ~ ~0.9 ~ tp @e[name=p5,type=pig,r=11,c=1] ~ ~ ~
execute @e[name=p5,type=pig] ~ ~0.9 ~ tp @e[name=p6,type=pig,r=11,c=1] ~ ~ ~
execute @e[name=p6,type=pig] ~ ~0.9 ~ tp @e[name=p7,type=pig,r=11,c=1] ~ ~ ~
execute @e[name=p7,type=pig] ~ ~0.9 ~ tp @e[name=p8,type=pig,r=11,c=1] ~ ~ ~
execute @e[name=p8,type=pig] ~ ~0.9 ~ tp @e[name=p9,type=villager,r=10,c=1] ~ ~ ~

execute @e[name=c1,type=creeper] ~ ~1.75 ~ tp @e[name=c2,type=creeper,r=14,c=1] ~ ~ ~
execute @e[name=c2,type=creeper] ~ ~1.75 ~ tp @e[name=c3,type=creeper,r=14,c=1] ~ ~ ~
execute @e[name=c3,type=creeper] ~ ~1.75 ~ tp @e[name=c4,type=creeper,r=14,c=1] ~ ~ ~
execute @e[name=c4,type=creeper] ~ ~1.75 ~ tp @e[name=c5,type=creeper,r=14,c=1] ~ ~ ~
execute @e[name=c5,type=creeper] ~ ~1.75 ~ tp @e[name=c6,type=creeper,r=14,c=1] ~ ~ ~
execute @e[name=c6,type=creeper] ~ ~1.75 ~ tp @e[name=c7,type=creeper,r=14,c=1] ~ ~ ~
execute @e[name=c7,type=creeper] ~ ~1.75 ~ tp @e[name=c8,type=creeper,r=14,c=1] ~ ~ ~
execute @e[name=c8,type=creeper] ~ ~1.75 ~ tp @e[name=c9,type=creeper,r=14,c=1] ~ ~ ~

execute @e[name=p1,type=zombie_pigman] ~ ~2.1 ~ tp @e[name=p2,type=zombie_pigman,r=15,c=1] ~ ~ ~
execute @e[name=p2,type=zombie_pigman] ~ ~2.1 ~ tp @e[name=p3,type=zombie_pigman,r=15,c=1] ~ ~ ~
execute @e[name=p3,type=zombie_pigman] ~ ~2.1 ~ tp @e[name=p4,type=zombie_pigman,r=15,c=1] ~ ~ ~
execute @e[name=p4,type=zombie_pigman] ~ ~2.1 ~ tp @e[name=p5,type=zombie_pigman,r=15,c=1] ~ ~ ~
execute @e[name=p5,type=zombie_pigman] ~ ~2.1 ~ tp @e[name=p6,type=zombie_pigman,r=15,c=1] ~ ~ ~
execute @e[name=p6,type=zombie_pigman] ~ ~2.1 ~ tp @e[name=p7,type=zombie_pigman,r=15,c=1] ~ ~ ~
execute @e[name=p7,type=zombie_pigman] ~ ~2.1 ~ tp @e[name=p8,type=zombie_pigman,r=15,c=1] ~ ~ ~
execute @e[name=p8,type=zombie_pigman] ~ ~2.1 ~ tp @e[name=p9,type=witch,r=15,c=1] ~ ~ ~