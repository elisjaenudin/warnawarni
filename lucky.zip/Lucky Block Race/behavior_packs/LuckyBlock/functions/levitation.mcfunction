effect @p[r=8,c=1] levitation 1 15 true
particle minecraft:knockback_roar_particle ~ ~1 ~