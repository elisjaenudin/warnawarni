setblock ~ ~16 ~ effect99:setdrop2
setblock ~ ~16 ~ air 0 destroy