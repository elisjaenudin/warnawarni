execute @e[type=lucky:giantblock,name=meteor1] ~ ~ ~ tp @s ~-0.16 ~-0.08 ~-0.16 ~3
execute @e[type=lucky:giantblock,name=meteor2] ~ ~ ~ tp @s ~0.16 ~-0.08 ~-0.16 ~3
execute @e[type=lucky:giantblock,name=meteor3] ~ ~ ~ tp @s ~0.16 ~-0.08 ~0.16 ~3
execute @e[type=lucky:giantblock,name=meteor4] ~ ~ ~ tp @s ~-0.16 ~-0.08 ~0.16 ~3