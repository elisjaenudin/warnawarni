execute @p[r=8,c=1] ~ ~ ~ fill ~2 ~ ~2 ~-2 ~2 ~-2 sandstone
execute @p[r=8,c=1] ~ ~ ~ fill ~1 ~1 ~1 ~-1 ~2 ~-1 air
execute @p[r=8,c=1] ~ ~ ~ fill ~-2 ~3 ~-2 ~-2 ~3 ~-2 gold_block
execute @p[r=8,c=1] ~ ~ ~ fill ~2 ~3 ~2 ~2 ~3 ~2 gold_block
execute @p[r=8,c=1] ~ ~ ~ fill ~-2 ~3 ~2 ~-2 ~3 ~2 gold_block
execute @p[r=8,c=1] ~ ~ ~ fill ~2 ~3 ~-2 ~2 ~3 ~-2 gold_block
execute @p[r=8,c=1] ~ ~ ~ fill ~-1 ~1 ~-1 ~-1 ~1 ~-1 effect99:lucky_block
execute @p[r=8,c=1] ~ ~ ~ fill ~1 ~1 ~1 ~1 ~1 ~1 effect99:lucky_block
execute @p[r=8,c=1] ~ ~ ~ fill ~-1 ~1 ~1 ~-1 ~1 ~1 effect99:lucky_block
execute @p[r=8,c=1] ~ ~ ~ fill ~1 ~1 ~-1 ~1 ~1 ~-1 effect99:lucky_block
execute @p[r=8,c=1] ~ ~ ~ tp @s ~ ~1 ~