effect @p[r=8,c=1] jump_boost 256 14 true
particle minecraft:totem_particle ~ ~1 ~