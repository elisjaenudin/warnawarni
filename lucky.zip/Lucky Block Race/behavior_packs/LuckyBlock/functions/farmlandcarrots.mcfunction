fill ~2 ~-1 ~2 ~-2 ~-1 ~-2 farmland
setblock ~ ~-1 ~ water
fill ~2 ~ ~2 ~-2 ~ ~-2 carrots