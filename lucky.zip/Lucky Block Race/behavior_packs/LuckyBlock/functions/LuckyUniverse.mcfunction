scoreboard objectives add Lucky dummy
gamerule commandblockoutput false
gamerule sendcommandfeedback false
scoreboard players add @p[r=5] Lucky 1
title @a[scores={Lucky=12000},r=4] actionbar §l§fCreated by §gEffect99
scoreboard players set @p[scores={Lucky=12001}] Lucky 1
scoreboard players set @p[scores={Lucky=12010}] Lucky 1
scoreboard players set @e[type=item,name=creeper] Lucky 666
scoreboard players set @e[type=item,name=slimes] Lucky 666
scoreboard players set @e[type=item,name=skeleton] Lucky 666
scoreboard players set @e[type=item,name=zombie] Lucky 666
scoreboard players set @e[type=item,name=spider] Lucky 666
scoreboard players set @e[type=item,name=cave_spider] Lucky 666
scoreboard players set @e[type=item,name=pillager] Lucky 666
scoreboard players set @e[type=item,name=silverfish] Lucky 666
scoreboard players set @e[type=item,name=blaze] Lucky 666
scoreboard players set @e[type=item,name=wither_skeleton] Lucky 666
scoreboard players set @e[type=item,name=evoker] Lucky 666
scoreboard players set @e[type=item,name=vindicator] Lucky 666
scoreboard players set @e[type=item,name=guardian] Lucky 666
scoreboard players set @e[type=item,name=phantom] Lucky 666
scoreboard players set @e[type=item,name=ghast] Lucky 666
scoreboard players set @e[type=item,name=vex] Lucky 666
scoreboard players set @e[type=item,name=ravager] Lucky 666
scoreboard players set @e[type=item,name=wither] Lucky 666
scoreboard players set @e[type=item,name=elder_guardian] Lucky 666
scoreboard players set @e[type=item,name=witch] Lucky 666
scoreboard players set @e[type=item,name=pufferfishs] Lucky 666
scoreboard players set @e[type=item,name=magma_cube] Lucky 666
scoreboard players set @e[type=item,name=electricreeper] Lucky 666
scoreboard players set @e[type=item,name=zombieg] Lucky 666
scoreboard players set @e[type=item,name=explode] Lucky 666
scoreboard players set @e[type=item,name=multirayo] Lucky 666
scoreboard players set @e[type=item,name=bob] Lucky 666
scoreboard players set @e[type=item,name=minispider] Lucky 666
scoreboard players set @e[type=item,name=meteor1] Lucky 666
scoreboard players set @e[type=item,name=meteor2] Lucky 666
scoreboard players set @e[type=item,name=meteor3] Lucky 666
scoreboard players set @e[type=item,name=meteor4] Lucky 666
scoreboard players set @e[type=item,name=multitnt] Lucky 666
scoreboard players set @e[type=item,name=entitytnt] Lucky 666
scoreboard players set @e[type=item,name=p2] Lucky 666
scoreboard players set @e[type=item,name=spread1] Lucky 666
scoreboard players set @e[type=item,name=minifall1] Lucky 666
scoreboard players set @e[type=item,name=shulker1] Lucky 666
scoreboard players set @e[type=item,name=captainv] Lucky 666
scoreboard players set @e[type=item,name=husk] Lucky 666
scoreboard players set @e[type=item,name=enderman] Lucky 666
scoreboard players set @e[type=item,name=c1] Lucky 666
scoreboard players set @e[type=item,name=p1] Lucky 111
scoreboard players set @e[type=item,name=dinnerbone1] Lucky 111
scoreboard players set @e[type=item,name=msjpotato] Lucky 111
scoreboard players set @e[type=item,name=ores1] Lucky 111
scoreboard players set @e[type=item,name=spread] Lucky 111
scoreboard players set @e[type=item,name=xp] Lucky 111
scoreboard players set @e[type=item,name=jeb_] Lucky 111
scoreboard players set @e[type=item,name=chicken] Lucky 111
scoreboard players set @e[type=item,name=cod] Lucky 111
scoreboard players set @e[type=item,name=pig] Lucky 111
scoreboard players set @e[type=item,name=cow] Lucky 111
scoreboard players set @e[type=item,name=sheep] Lucky 111
scoreboard players set @e[type=item,name=wolf] Lucky 111
scoreboard players set @e[type=item,name=cat] Lucky 111
scoreboard players set @e[type=item,name=parrot] Lucky 111
scoreboard players set @e[type=item,name=rabbit] Lucky 111
scoreboard players set @e[type=item,name=polar] Lucky 111
scoreboard players set @e[type=item,name=trader] Lucky 111
scoreboard players set @e[type=item,name=horse] Lucky 111
scoreboard players set @e[type=item,name=bee] Lucky 111
scoreboard players set @e[type=item,name=fox] Lucky 111
scoreboard players set @e[type=item,name=panda] Lucky 111
scoreboard players set @e[type=item,name=turtle] Lucky 111
scoreboard players set @e[type=item,name=zombie_horse] Lucky 111
scoreboard players set @e[type=item,name=skeleton_horse] Lucky 111
scoreboard players set @e[type=item,name=villager] Lucky 111
scoreboard players set @e[type=item,name=bat] Lucky 111
scoreboard players set @e[type=item,name=villagerhouse] Lucky 100
scoreboard players set @e[type=item,name=tnts] Lucky 100
scoreboard players set @e[type=item,name=table] Lucky 100
scoreboard players set @e[type=item,name=slimecastle] Lucky 100
scoreboard players set @e[type=item,name=sandglass] Lucky 100
scoreboard players set @e[type=item,name=pyramid] Lucky 100
scoreboard players set @e[type=item,name=obsidians] Lucky 100
scoreboard players set @e[type=item,name=minifall] Lucky 100
scoreboard players set @e[type=item,name=luckysandstone] Lucky 100
scoreboard players set @e[type=item,name=luckybars] Lucky 100
scoreboard players set @e[type=item,name=lavaglass] Lucky 100
scoreboard players set @e[type=item,name=lavabars] Lucky 100
scoreboard players set @e[type=item,name=house] Lucky 100
scoreboard players set @e[type=item,name=fuente] Lucky 100
scoreboard players set @e[type=item,name=fire] Lucky 100
scoreboard players set @e[type=item,name=farmlandmelon] Lucky 100
scoreboard players set @e[type=item,name=farmlandcarrots] Lucky 100
scoreboard players set @e[type=item,name=extremefall] Lucky 100
scoreboard players set @e[type=item,name=endplant] Lucky 100
scoreboard players set @e[type=item,name=dirthouse] Lucky 100
scoreboard players set @e[type=item,name=arbol] Lucky 100
scoreboard players set @e[type=item,name=anvilbars] Lucky 100
scoreboard players set @e[type=item,name=yunq] Lucky 100
scoreboard players set @e[type=item,name=luckyblock] Lucky 100
scoreboard players set @e[type=item,name=mining] Lucky 355
scoreboard players set @e[type=item,name=jump] Lucky 355
scoreboard players set @e[type=item,name=speed] Lucky 355
scoreboard players set @e[type=item,name=slow] Lucky 355
scoreboard players set @e[type=item,name=nausea] Lucky 355
scoreboard players set @e[type=item,name=poison] Lucky 355
scoreboard players set @e[type=item,name=levitation] Lucky 355
scoreboard players set @e[type=item,name=blind] Lucky 355

execute @e[type=item,name=creeper,scores={Lucky=666}] ~ ~ ~ summon creeper
execute @e[type=item,name=slimes,scores={Lucky=666}] ~ ~ ~ summon slime
execute @e[type=item,name=skeleton,scores={Lucky=666}] ~ ~ ~ summon skeleton
execute @e[type=item,name=zombie,scores={Lucky=666}] ~ ~ ~ summon zombie
execute @e[type=item,name=spider,scores={Lucky=666}] ~ ~ ~ summon spider
execute @e[type=item,name=cave_spider,scores={Lucky=666}] ~ ~ ~ summon cave_spider
execute @e[type=item,name=pillager,scores={Lucky=666}] ~ ~ ~ summon pillager
execute @e[type=item,name=silverfish,scores={Lucky=666}] ~ ~ ~ summon silverfish
execute @e[type=item,name=blaze,scores={Lucky=666}] ~ ~ ~ summon blaze
execute @e[type=item,name=wither_skeleton,scores={Lucky=666}] ~ ~ ~ summon wither_skeleton
execute @e[type=item,name=evoker,scores={Lucky=666}] ~ ~ ~ summon evocation_illager
execute @e[type=item,name=vindicator,scores={Lucky=666}] ~ ~ ~ summon vindicator
execute @e[type=item,name=guardian,scores={Lucky=666}] ~ ~ ~ summon guardian
execute @e[type=item,name=phantom,scores={Lucky=666}] ~ ~ ~ summon phantom
execute @e[type=item,name=ghast,scores={Lucky=666}] ~ ~ ~ summon ghast
execute @e[type=item,name=vex,scores={Lucky=666}] ~ ~ ~ summon vex
execute @e[type=item,name=ravager,scores={Lucky=666}] ~ ~ ~ summon ravager
execute @e[type=item,name=wither,scores={Lucky=666}] ~ ~ ~ summon wither
execute @e[type=item,name=elder_guardian,scores={Lucky=666}] ~ ~ ~ summon elder_guardian
execute @e[type=item,name=witch,scores={Lucky=666}] ~ ~ ~ summon witch
execute @e[type=item,name=pufferfishs,scores={Lucky=666}] ~ ~ ~ summon pufferfish
execute @e[type=item,name=magma_cube,scores={Lucky=666}] ~ ~ ~ summon magma_cube
execute @e[type=item,name=electricreeper,scores={Lucky=666}] ~ ~ ~ function electricreeper
execute @e[type=item,name=zombieg,scores={Lucky=666}] ~ ~ ~ summon lucky:zombie_giant
execute @e[type=item,name=explode,scores={Lucky=666}] ~ ~ ~ summon lucky:explode
execute @e[type=item,name=multirayo,scores={Lucky=666}] ~ ~ ~ function multirayo
execute @e[type=item,name=bob,scores={Lucky=666}] ~ ~ ~ summon zombie §l§eBob ~ ~ ~
execute @e[type=item,name=minispider,scores={Lucky=666}] ~ ~ ~ summon lucky:minispider
execute @e[type=item,name=meteor1,scores={Lucky=666}] ~ ~ ~ function meteor1
execute @e[type=item,name=meteor2,scores={Lucky=666}] ~ ~ ~ function meteor2
execute @e[type=item,name=meteor3,scores={Lucky=666}] ~ ~ ~ function meteor3
execute @e[type=item,name=meteor4,scores={Lucky=666}] ~ ~ ~ function meteor4
execute @e[type=item,name=multitnt,scores={Lucky=666}] ~ ~ ~ function multitnt
execute @e[type=item,name=entitytnt,scores={Lucky=666}] ~ ~ ~ summon tnt
execute @e[type=item,name=p2,scores={Lucky=666}] ~ ~ ~ function p2
execute @e[type=item,name=spread1,scores={Lucky=666}] ~ ~ ~ function spread1
execute @e[type=item,name=minifall1,scores={Lucky=666}] ~ ~ ~ function minifall1
execute @e[type=item,name=shulker1,scores={Lucky=666}] ~ ~ ~ summon shulker ~ ~ ~ minecraft:turn_black
execute @e[type=item,name=captainv,scores={Lucky=666}] ~ ~ ~ summon vindicator ~ ~ ~ minecraft:spawn_as_illager_captain
execute @e[type=item,name=husk,scores={Lucky=666}] ~ ~ ~ summon husk
execute @e[type=item,name=enderman,scores={Lucky=666}] ~ ~ ~ summon enderman ~ ~ ~ minecraft:become_angry
execute @e[type=item,name=c1,scores={Lucky=666}] ~ ~ ~ function c1
execute @e[type=item,name=p1,scores={Lucky=111}] ~ ~ ~ function p1
execute @e[type=item,name=dinnerbone1,scores={Lucky=111}] ~ ~ ~ summon horse Dinnerbone ~ ~ ~
execute @e[type=item,name=msjpotato,scores={Lucky=111}] ~ ~ ~ function msjpotato
execute @e[type=item,name=ores1,scores={Lucky=111}] ~ ~ ~ function setdrop_ores
execute @e[type=item,name=spread,scores={Lucky=111}] ~ ~ ~ function spread
execute @e[type=item,name=xp,scores={Lucky=111}] ~ ~ ~ summon lucky:xp
execute @e[type=item,name=jeb_,scores={Lucky=111}] ~ ~ ~ summon sheep jeb_ ~ ~ ~
execute @e[type=item,name=chicken,scores={Lucky=111}] ~ ~ ~ summon chicken
execute @e[type=item,name=cod,scores={Lucky=111}] ~ ~ ~ summon cod
execute @e[type=item,name=pig,scores={Lucky=111}] ~ ~ ~ summon pig
execute @e[type=item,name=cow,scores={Lucky=111}] ~ ~ ~ summon cow
execute @e[type=item,name=sheep,scores={Lucky=111}] ~ ~ ~ summon sheep
execute @e[type=item,name=wolf,scores={Lucky=111}] ~ ~ ~ summon wolf
execute @e[type=item,name=cat,scores={Lucky=111}] ~ ~ ~ summon cat
execute @e[type=item,name=parrot,scores={Lucky=111}] ~ ~ ~ summon parrot
execute @e[type=item,name=rabbit,scores={Lucky=111}] ~ ~ ~ summon rabbit
execute @e[type=item,name=polar,scores={Lucky=111}] ~ ~ ~ summon polar_bear
execute @e[type=item,name=trader,scores={Lucky=111}] ~ ~ ~ summon wandering_trader
execute @e[type=item,name=horse,scores={Lucky=111}] ~ ~ ~ summon horse
execute @e[type=item,name=bee,scores={Lucky=111}] ~ ~ ~ summon minecraft:bee
execute @e[type=item,name=fox,scores={Lucky=111}] ~ ~ ~ summon fox
execute @e[type=item,name=panda,scores={Lucky=111}] ~ ~ ~ summon panda
execute @e[type=item,name=turtle,scores={Lucky=111}] ~ ~ ~ summon turtle
execute @e[type=item,name=zombie_horse,scores={Lucky=111}] ~ ~ ~ summon zombie_horse
execute @e[type=item,name=skeleton_horse,scores={Lucky=111}] ~ ~ ~ summon skeleton_horse
execute @e[type=item,name=villager,scores={Lucky=111}] ~ ~ ~ summon villager
execute @e[type=item,name=bat,scores={Lucky=111}] ~ ~ ~ summon bat
execute @e[type=item,name=villagerhouse,scores={Lucky=100}] ~ ~ ~ function villagerhouse
execute @e[type=item,name=tnts,scores={Lucky=100}] ~ ~ ~ function tnts
execute @e[type=item,name=table,scores={Lucky=100}] ~ ~ ~ function table
execute @e[type=item,name=slimecastle,scores={Lucky=100}] ~ ~ ~ function slimecastle
execute @e[type=item,name=sandglass,scores={Lucky=100}] ~ ~ ~ function sandglass
execute @e[type=item,name=pyramid,scores={Lucky=100}] ~ ~ ~ function pyramid
execute @e[type=item,name=obsidians,scores={Lucky=100}] ~ ~ ~ function obsidians
execute @e[type=item,name=minifall,scores={Lucky=100}] ~ ~ ~ function minifall
execute @e[type=item,name=luckysandstone,scores={Lucky=100}] ~ ~ ~ function luckysandstone
execute @e[type=item,name=luckybars,scores={Lucky=100}] ~ ~ ~ function luckybars
execute @e[type=item,name=lavaglass,scores={Lucky=100}] ~ ~ ~ function lavaglass
execute @e[type=item,name=lavabars,scores={Lucky=100}] ~ ~ ~ function lavabars
execute @e[type=item,name=house,scores={Lucky=100}] ~ ~ ~ function house
execute @e[type=item,name=fuente,scores={Lucky=100}] ~ ~ ~ function fuente
execute @e[type=item,name=fire,scores={Lucky=100}] ~ ~ ~ function fire
execute @e[type=item,name=farmlandmelon,scores={Lucky=100}] ~ ~ ~ function farmlandmelon
execute @e[type=item,name=farmlandcarrots,scores={Lucky=100}] ~ ~ ~ function farmlandcarrots
execute @e[type=item,name=extremefall,scores={Lucky=100}] ~ ~ ~ function extremefall
execute @e[type=item,name=endplant,scores={Lucky=100}] ~ ~ ~ function endplant
execute @e[type=item,name=dirthouse,scores={Lucky=100}] ~ ~ ~ function dirthouse
execute @e[type=item,name=arbol,scores={Lucky=100}] ~ ~ ~ function arbol
execute @e[type=item,name=anvilbars,scores={Lucky=100}] ~ ~ ~ function anvilbars
execute @e[type=item,name=yunq,scores={Lucky=100}] ~ ~ ~ function yunq
execute @e[type=item,name=luckyblock,scores={Lucky=100}] ~ ~ ~ function luckyblock
execute @e[type=item,name=mining,scores={Lucky=355}] ~ ~ ~ function haste
execute @e[type=item,name=jump,scores={Lucky=355}] ~ ~ ~ function jump
execute @e[type=item,name=speed,scores={Lucky=355}] ~ ~ ~ function speed
execute @e[type=item,name=slow,scores={Lucky=355}] ~ ~ ~ function slow
execute @e[type=item,name=nausea,scores={Lucky=355}] ~ ~ ~ function nausea
execute @e[type=item,name=poison,scores={Lucky=355}] ~ ~ ~ function poison
execute @e[type=item,name=levitation,scores={Lucky=355}] ~ ~ ~ function levitation
execute @e[type=item,name=blind,scores={Lucky=355}] ~ ~ ~ function blind     
function fft
function bob
function meteor
function luckyblockf
function towers
function crafting

execute @e[type=item,name=creeper,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=slimes,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=skeleton,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=zombie,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=spider,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=cave_spider,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=pillager,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=silverfish,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=blaze,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=wither_skeleton,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=evoker,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=vindicator,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=guardian,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=phantom,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=ghast,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=vex,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=ravager,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=wither,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=elder_guardian,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=witch,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=pufferfishs,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=magma_cube,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=electricreeper,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=zombieg,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=explode,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=multirayo,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=bob,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=minispider,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=meteor1,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=meteor2,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=meteor3,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=meteor4,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=multitnt,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=entitytnt,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=c1,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=p2,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=spread1,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=minifall1,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=shulker1,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=captainv,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=husk,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=enderman,scores={Lucky=666}] ~ ~ ~ kill @s
execute @e[type=item,name=p1,scores={Lucky=111}] ~ ~ ~ kill @s
execute @e[type=item,name=dinnerbone1,scores={Lucky=111}] ~ ~ ~ kill @s
execute @e[type=item,name=msjpotato,scores={Lucky=111}] ~ ~ ~ kill @s
execute @e[type=item,name=ores1,scores={Lucky=111}] ~ ~ ~ kill @s
execute @e[type=item,name=spread,scores={Lucky=111}] ~ ~ ~ kill @s
execute @e[type=item,name=xp,scores={Lucky=111}] ~ ~ ~ kill @s
execute @e[type=item,name=jeb_,scores={Lucky=111}] ~ ~ ~ kill @s
execute @e[type=item,name=chicken,scores={Lucky=111}] ~ ~ ~ kill @s
execute @e[type=item,name=cod,scores={Lucky=111}] ~ ~ ~ kill @s
execute @e[type=item,name=pig,scores={Lucky=111}] ~ ~ ~ kill @s
execute @e[type=item,name=cow,scores={Lucky=111}] ~ ~ ~ kill @s
execute @e[type=item,name=sheep,scores={Lucky=111}] ~ ~ ~ kill @s
execute @e[type=item,name=wolf,scores={Lucky=111}] ~ ~ ~ kill @s
execute @e[type=item,name=cat,scores={Lucky=111}] ~ ~ ~ kill @s
execute @e[type=item,name=parrot,scores={Lucky=111}] ~ ~ ~ kill @s
execute @e[type=item,name=rabbit,scores={Lucky=111}] ~ ~ ~ kill @s
execute @e[type=item,name=polar,scores={Lucky=111}] ~ ~ ~ kill @s
execute @e[type=item,name=trader,scores={Lucky=111}] ~ ~ ~ kill @s
execute @e[type=item,name=horse,scores={Lucky=111}] ~ ~ ~ kill @s
execute @e[type=item,name=bee,scores={Lucky=111}] ~ ~ ~ kill @s
execute @e[type=item,name=fox,scores={Lucky=111}] ~ ~ ~ kill @s
execute @e[type=item,name=panda,scores={Lucky=111}] ~ ~ ~ kill @s
execute @e[type=item,name=turtle,scores={Lucky=111}] ~ ~ ~ kill @s
execute @e[type=item,name=zombie_horse,scores={Lucky=111}] ~ ~ ~ kill @s
execute @e[type=item,name=skeleton_horse,scores={Lucky=111}] ~ ~ ~ kill @s
execute @e[type=item,name=villager,scores={Lucky=111}] ~ ~ ~ kill @s
execute @e[type=item,name=bat,scores={Lucky=111}] ~ ~ ~ kill @s
execute @e[type=item,name=villagerhouse,scores={Lucky=100}] ~ ~ ~ kill @s
execute @e[type=item,name=tnts,scores={Lucky=100}] ~ ~ ~ kill @s
execute @e[type=item,name=table,scores={Lucky=100}] ~ ~ ~ kill @s
execute @e[type=item,name=slimecastle,scores={Lucky=100}] ~ ~ ~ kill @s
execute @e[type=item,name=sandglass,scores={Lucky=100}] ~ ~ ~ kill @s
execute @e[type=item,name=pyramid,scores={Lucky=100}] ~ ~ ~ kill @s
execute @e[type=item,name=obsidians,scores={Lucky=100}] ~ ~ ~ kill @s
execute @e[type=item,name=minifall,scores={Lucky=100}] ~ ~ ~ kill @s
execute @e[type=item,name=luckysandstone,scores={Lucky=100}] ~ ~ ~ kill @s
execute @e[type=item,name=luckybars,scores={Lucky=100}] ~ ~ ~ kill @s
execute @e[type=item,name=lavaglass,scores={Lucky=100}] ~ ~ ~ kill @s
execute @e[type=item,name=lavabars,scores={Lucky=100}] ~ ~ ~ kill @s
execute @e[type=item,name=house,scores={Lucky=100}] ~ ~ ~ kill @s
execute @e[type=item,name=fuente,scores={Lucky=100}] ~ ~ ~ kill @s
execute @e[type=item,name=fire,scores={Lucky=100}] ~ ~ ~ kill @s
execute @e[type=item,name=farmlandmelon,scores={Lucky=100}] ~ ~ ~ kill @s
execute @e[type=item,name=farmlandcarrots,scores={Lucky=100}] ~ ~ ~ kill @s
execute @e[type=item,name=extremefall,scores={Lucky=100}] ~ ~ ~ kill @s
execute @e[type=item,name=endplant,scores={Lucky=100}] ~ ~ ~ kill @s
execute @e[type=item,name=dirthouse,scores={Lucky=100}] ~ ~ ~ kill @s
execute @e[type=item,name=arbol,scores={Lucky=100}] ~ ~ ~ kill @s
execute @e[type=item,name=anvilbars,scores={Lucky=100}] ~ ~ ~ kill @s
execute @e[type=item,name=yunq,scores={Lucky=100}] ~ ~ ~ kill @s
execute @e[type=item,name=luckyblock,scores={Lucky=100}] ~ ~ ~ kill @s
execute @e[type=item,name=mining,scores={Lucky=355}] ~ ~ ~ kill @s
execute @e[type=item,name=jump,scores={Lucky=355}] ~ ~ ~ kill @s
execute @e[type=item,name=speed,scores={Lucky=355}] ~ ~ ~ kill @s
execute @e[type=item,name=slow,scores={Lucky=355}] ~ ~ ~ kill @s
execute @e[type=item,name=nausea,scores={Lucky=355}] ~ ~ ~ kill @s
execute @e[type=item,name=poison,scores={Lucky=355}] ~ ~ ~ kill @s
execute @e[type=item,name=levitation,scores={Lucky=355}] ~ ~ ~ kill @s
execute @e[type=item,name=blind,scores={Lucky=355}] ~ ~ ~ kill @s