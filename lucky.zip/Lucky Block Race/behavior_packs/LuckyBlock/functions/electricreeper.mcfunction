summon creeper
summon lightning_bolt ~ ~1 ~
effect @e[type=creeper] fire_resistance 10 0 true
