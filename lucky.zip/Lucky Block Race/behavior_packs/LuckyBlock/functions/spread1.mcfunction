playsound mob.endermen.portal @p
spreadplayers ~ ~ 50 100 @p