summon pig ~ ~ ~ minecraft:ageable_grow_up p1
summon pig ~ ~ ~ minecraft:ageable_grow_up p2
summon pig ~ ~ ~ minecraft:ageable_grow_up p3
summon pig ~ ~ ~ minecraft:ageable_grow_up p4
summon pig ~ ~ ~ minecraft:ageable_grow_up p5
summon pig ~ ~ ~ minecraft:ageable_grow_up p6
summon pig ~ ~ ~ minecraft:ageable_grow_up p7
summon pig ~ ~ ~ minecraft:ageable_grow_up p8
summon villager ~ ~ ~ minecraft:ageable_grow_up p9
summon lightning_bolt ~ ~ ~