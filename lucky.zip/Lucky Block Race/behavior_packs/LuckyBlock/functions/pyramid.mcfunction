execute @p[r=8,c=1] ~ ~ ~ fill ~3 ~ ~-3 ~3 ~ ~3 sandstone_stairs 1
execute @p[r=8,c=1] ~ ~ ~ fill ~-3 ~ ~3 ~-3 ~ ~-3 sandstone_stairs 8
execute @p[r=8,c=1] ~ ~ ~ fill ~-3 ~ ~-3 ~3 ~ ~-3 sandstone_stairs 2
execute @p[r=8,c=1] ~ ~ ~ fill ~3 ~ ~3 ~-3 ~ ~3 sandstone_stairs 3
execute @p[r=8,c=1] ~ ~ ~ fill ~2 ~1 ~-2 ~2 ~1 ~2 sandstone_stairs 1
execute @p[r=8,c=1] ~ ~ ~ fill ~-2 ~1 ~2 ~-2 ~1 ~-2 sandstone_stairs 8
execute @p[r=8,c=1] ~ ~ ~ fill ~-2 ~1 ~-2 ~2 ~1 ~-2 sandstone_stairs 2
execute @p[r=8,c=1] ~ ~ ~ fill ~2 ~1 ~2 ~-2 ~1 ~2 sandstone_stairs 3
execute @p[r=8,c=1] ~ ~ ~ fill ~1 ~2 ~-1 ~1 ~2 ~1 sandstone_stairs 1
execute @p[r=8,c=1] ~ ~ ~ fill ~-1 ~2 ~1 ~-1 ~2 ~-1 sandstone_stairs 8
execute @p[r=8,c=1] ~ ~ ~ fill ~-1 ~2 ~-1 ~1 ~2 ~-1 sandstone_stairs 2
execute @p[r=8,c=1] ~ ~ ~ fill ~1 ~2 ~1 ~-1 ~2 ~1 sandstone_stairs 3
execute @p[r=8,c=1] ~ ~ ~ setblock ~ ~3 ~ gold_block
execute @p[r=8,c=1] ~ ~ ~ fill ~-3 ~ ~-3 ~-3 ~1 ~-3 sandstone
execute @p[r=8,c=1] ~ ~ ~ fill ~3 ~ ~3 ~3 ~1 ~3 sandstone
execute @p[r=8,c=1] ~ ~ ~ fill ~-3 ~ ~3 ~-3 ~1 ~3 sandstone
execute @p[r=8,c=1] ~ ~ ~ fill ~3 ~ ~-3 ~3 ~1 ~-3 sandstone
execute @p[r=8,c=1] ~ ~ ~ fill ~-3 ~2 ~-3 ~-3 ~2 ~-3 sandstone 1
execute @p[r=8,c=1] ~ ~ ~ fill ~3 ~2 ~3 ~3 ~2 ~3 sandstone 1
execute @p[r=8,c=1] ~ ~ ~ fill ~-3 ~2 ~3 ~-3 ~2 ~3 sandstone 1
execute @p[r=8,c=1] ~ ~ ~ fill ~3 ~2 ~-3 ~3 ~2 ~-3 sandstone 1
execute @p[r=8,c=1] ~ ~ ~ fill ~-3 ~3 ~-3 ~-3 ~3 ~-3 gold_block
execute @p[r=8,c=1] ~ ~ ~ fill ~3 ~3 ~3 ~3 ~3 ~3 gold_block
execute @p[r=8,c=1] ~ ~ ~ fill ~-3 ~3 ~3 ~-3 ~3 ~3 gold_block
execute @p[r=8,c=1] ~ ~ ~ fill ~3 ~3 ~-3 ~3 ~3 ~-3 gold_block
execute @p[r=8,c=1] ~ ~ ~ setblock ~-2 ~ ~-2 effect99:lucky_block
execute @p[r=8,c=1] ~ ~ ~ setblock ~2 ~ ~2 effect99:lucky_block
execute @p[r=8,c=1] ~ ~ ~ setblock ~-2 ~ ~2 effect99:lucky_block
execute @p[r=8,c=1] ~ ~ ~ setblock ~2 ~ ~-2 effect99:lucky_block
execute @p[r=8,c=1] ~ ~ ~ setblock ~-2 ~ ~ effect99:lucky_block
execute @p[r=8,c=1] ~ ~ ~ setblock ~2 ~ ~ effect99:lucky_block
execute @p[r=8,c=1] ~ ~ ~ setblock ~ ~ ~2 effect99:lucky_block
execute @p[r=8,c=1] ~ ~ ~ setblock ~ ~ ~-2 effect99:lucky_block
execute @p[r=8,c=1] ~ ~ ~ setblock ~ ~ ~ torch