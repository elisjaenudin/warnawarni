execute @e[type=item,name=luckyblockf] ~ ~ ~ fill ~5 ~-5 ~5 ~-5 ~5 ~-5 air 0 replace stained_glass
playsound random.orb @p
particle minecraft:knockback_roar_particle ~ ~1 ~