effect @p[r=8,c=1] blindness 10 1 true
particle minecraft:knockback_roar_particle ~ ~1 ~