### One Block 1.0 Alphatest By CuBeyzM { It is forbidden to change or steal our content without the knowledge of the manager or content owner, to get permission or information you can contact us via gmail : blessingcraftmc@gmail.com }
gamerule commandblockoutput false
gamerule functioncommandlimit 1000
gamerule sendcommandfeedback false

tp @a[tag=!login] 10003 50 10000
tellraw @a[tag=!login] {"rawtext":[{"text":"§7[§bOneBlock§7] §aWelcome to One Block §e"},{"selector":"@a[tag=!login]"}]}
spawnpoint @a[tag=hub,x=10003,y=50,z=10000,r=3] 10003 50 10000
tag @a[x=10003,y=50,z=10000,r=3] add login
tag @a[tag=!play,x=10003,y=50,z=10000,r=3] add hub

execute @e[tag=system] ~ ~ ~ tag @a[tag=hub,x=10021,y=49,z=10000,dx=2,dy=2,dz=1] add play
tag @a[tag=play,tag=hub] remove hub
tp @a[tag=play,tag=!player] 0 50 0
spawnpoint @a[tag=play,tag=!player] 0 50 0
execute @a[tag=play,tag=!player] ~ ~ ~ fill 0 50 0 0 51 0 air
tellraw @a[tag=play,tag=!player] {"rawtext":[{"text":"§7[§bHelper§7] §aHow to play One Block is to destroy the blocks below you at this time to get rare items and blocks, the more blocks you destroy, the greater the chance to get rare items§e!"}]}
tag @a[tag=play,tag=!player,x=0,y=50,z=0,r=3] add player

gamemode a @a[tag=hub,tag=!play]
gamemode s @a[tag=play,tag=!hub]
scoreboard players add @a poin 0
scoreboard players operation @p poindisplay = @p poin
scoreboard players operation @p blockdisplay = @p poin
scoreboard objectives setdisplay list poindisplay
scoreboard objectives setdisplay belowname blockdisplay

### One System
scoreboard objectives add poindisplay dummy "§c§o# §r§eLeaderboard"
scoreboard objectives add blockdisplay dummy "BP "
scoreboard objectives add air dummy
scoreboard objectives add block dummy
scoreboard objectives add tier dummy
scoreboard objectives add cd dummy
scoreboard objectives add poin dummy

execute @a[scores={poin=0..99}] ~ ~ ~ tag @e[tag=system] add tier1
execute @a[scores={poin=100..400}] ~ ~ ~ tag @e[tag=system] add tier2
execute @a[scores={poin=401..1000}] ~ ~ ~ tag @e[tag=system] add tier3
execute @a[scores={poin=1001..}] ~ ~ ~ tag @e[tag=system] add tier4

scoreboard players set @e[tag=system,tag=tier1,tag=!tier2,tag=!tier3,tag=!tier4] tier 1
scoreboard players set @e[tag=system,tag=tier2,tag=!tier3,tag=!tier4] tier 2
scoreboard players set @e[tag=system,tag=tier3,tag=!tier4] tier 3
scoreboard players set @e[tag=tier4] tier 4

execute @a[scores={poin=100..400}] ~ ~ ~ execute @e[tag=system,tag=!txt2] ~ ~ ~ tellraw @a[tag=play] {"rawtext":[{"text":"§3§lTier §eI §7§l- §r§3§lTier §eII"}]}
execute @a[scores={poin=100..400}] ~ ~ ~ execute @e[tag=system,tag=!txt2] ~ ~ ~ tellraw @a[tag=play] {"rawtext":[{"text":" "}]}
execute @a[scores={poin=100..400}] ~ ~ ~ execute @e[tag=system,tag=!txt2] ~ ~ ~ tellraw @a[tag=play] {"rawtext":[{"text":"§aBlock Cooldown §7 -§e0.5s §a- §e0.4s"}]}
execute @a[scores={poin=100..400}] ~ ~ ~ execute @e[tag=system,tag=!txt2] ~ ~ ~ tellraw @a[tag=play] {"rawtext":[{"text":"§aBonus Item §7- §bIce"}]}
execute @a[scores={poin=100..400}] ~ ~ ~ execute @e[tag=system,tag=!txt2] ~ ~ ~ tellraw @a[tag=play] {"rawtext":[{"text":"§aNew block§e! §7- §fIron Ore"}]}
execute @a[scores={poin=100..400}] ~ ~ ~ execute @e[tag=system,tag=!txt2] ~ ~ ~ tellraw @a[tag=play] {"rawtext":[{"text":" "}]}
execute @a[scores={poin=100..400}] ~ ~ ~ execute @e[tag=system,tag=!txt2] ~ ~ ~ execute @a ~ ~ ~ playsound random.levelup @a[tag=play] ~ ~ ~
execute @a[scores={poin=100..400}] ~ ~ ~ execute @e[tag=system,tag=!txt2] ~ ~ ~ give @p[tag=play,x=0,y=50,z=0,r=6] ice 2 0
execute @a[scores={poin=100..400}] ~ ~ ~ execute @e[tag=system,tag=!txt2] ~ ~ ~ tag @e[tag=system] add txt2

execute @a[scores={poin=401..1000}] ~ ~ ~ execute @e[tag=system,tag=!txt3] ~ ~ ~ tellraw @a[tag=play] {"rawtext":[{"text":"§3§lTier §eII §7§l- §r§3§lTier §eIII"}]}
execute @a[scores={poin=401..1000}] ~ ~ ~ execute @e[tag=system,tag=!txt3] ~ ~ ~ tellraw @a[tag=play] {"rawtext":[{"text":" "}]}
execute @a[scores={poin=401..1000}] ~ ~ ~ execute @e[tag=system,tag=!txt3] ~ ~ ~ tellraw @a[tag=play] {"rawtext":[{"text":"§aBlock Cooldown §7 -§e0.4s §a- §e0.3s"}]}
execute @a[scores={poin=401..1000}] ~ ~ ~ execute @e[tag=system,tag=!txt3] ~ ~ ~ tellraw @a[tag=play] {"rawtext":[{"text":"§aBonus Item §7- §dObsidian§7, §aSugar Cane"}]}
execute @a[scores={poin=401..1000}] ~ ~ ~ execute @e[tag=system,tag=!txt3] ~ ~ ~ tellraw @a[tag=play] {"rawtext":[{"text":"§aNew block§e! §7- §bDiamond Ore§7, §1Lapis Ore§7,§fSand§7, §8Gravel"}]}
execute @a[scores={poin=401..1000}] ~ ~ ~ execute @e[tag=system,tag=!txt3] ~ ~ ~ tellraw @a[tag=play] {"rawtext":[{"text":" "}]}
execute @a[scores={poin=401..1000}] ~ ~ ~ execute @e[tag=system,tag=!txt3] ~ ~ ~ execute @a ~ ~ ~ playsound random.levelup @a[tag=play] ~ ~ ~
execute @a[scores={poin=401..1000}] ~ ~ ~ execute @e[tag=system,tag=!txt3] ~ ~ ~ give @p[tag=play,x=0,y=50,z=0,r=6] obsidian 12 0
execute @a[scores={poin=401..1000}] ~ ~ ~ execute @e[tag=system,tag=!txt3] ~ ~ ~ give @p[tag=play,x=0,y=50,z=0,r=6] sugar_cane 3 0
execute @a[scores={poin=401..1000}] ~ ~ ~ execute @e[tag=system,tag=!txt3] ~ ~ ~ tag @e[tag=system] add txt3

execute @a[scores={poin=1001..}] ~ ~ ~ execute @e[tag=system,tag=!txt4] ~ ~ ~ tellraw @a[tag=play] {"rawtext":[{"text":"§3§lTier §eIII §7§l- §r§3§lTier §eMAX"}]}
execute @a[scores={poin=1001..}] ~ ~ ~ execute @e[tag=system,tag=!txt4] ~ ~ ~ tellraw @a[tag=play] {"rawtext":[{"text":" "}]}
execute @a[scores={poin=1001..}] ~ ~ ~ execute @e[tag=system,tag=!txt4] ~ ~ ~ tellraw @a[tag=play] {"rawtext":[{"text":"§aBlock Cooldown §7 -§e0.3s §a- §e0.1s"}]}
execute @a[scores={poin=1001..}] ~ ~ ~ execute @e[tag=system,tag=!txt4] ~ ~ ~ tellraw @a[tag=play] {"rawtext":[{"text":"§aBonus Item §7- §dEnder Pearl§7, §3Ender Portal Frame"}]}
execute @a[scores={poin=1001..}] ~ ~ ~ execute @e[tag=system,tag=!txt4] ~ ~ ~ tellraw @a[tag=play] {"rawtext":[{"text":"§aNew block§e! §7- §cRedstone Ore§7, §gGold Ore§7"}]}
execute @a[scores={poin=1001..}] ~ ~ ~ execute @e[tag=system,tag=!txt4] ~ ~ ~ tellraw @a[tag=play] {"rawtext":[{"text":" "}]}
execute @a[scores={poin=1001..}] ~ ~ ~ execute @e[tag=system,tag=!txt4] ~ ~ ~ execute @a ~ ~ ~ playsound random.levelup @a[tag=play] ~ ~ ~
execute @a[scores={poin=1001..}] ~ ~ ~ execute @e[tag=system,tag=!txt4] ~ ~ ~ give @p[tag=play,x=0,y=50,z=0,r=6] ender_pearl 6 0
execute @a[scores={poin=1001..}] ~ ~ ~ execute @e[tag=system,tag=!txt4] ~ ~ ~ give @p[tag=play,x=0,y=50,z=0,r=6] end_portal_frame 12 0
execute @a[scores={poin=1001..}] ~ ~ ~ execute @e[tag=system,tag=!txt4] ~ ~ ~ tag @e[tag=system] add txt4

execute @e[tag=system,scores={tier=1,air=1}] ~ ~ ~ scoreboard players add @e[tag=system] cd 0
execute @e[tag=system,scores={tier=1,air=1}] ~ ~ ~ scoreboard players add @e[tag=system,scores={cd=..10}] cd 1
execute @e[tag=system,scores={tier=1,air=1}] ~ ~ ~ scoreboard players random @e[tag=system] block 1 100
execute @e[tag=system,scores={tier=1,air=1}] ~ ~ ~ fill 0 49 0 0 49 0 barrier 0 replace air
execute @e[tag=system,scores={tier=1,cd=10,block=1..16}] ~ ~ ~ setblock 0 49 0 cobblestone
execute @e[tag=system,scores={tier=1,cd=10,block=17..32}] ~ ~ ~ setblock 0 49 0 stone 3
execute @e[tag=system,scores={tier=1,cd=10,block=33..48}] ~ ~ ~ setblock 0 49 0 stone 1
execute @e[tag=system,scores={tier=1,cd=10,block=49..54}] ~ ~ ~ setblock 0 49 0 coal_ore
execute @e[tag=system,scores={tier=1,cd=10,block=55..61}] ~ ~ ~ setblock 0 49 0 cobblestone
execute @e[tag=system,scores={tier=1,cd=10,block=62..69}] ~ ~ ~ setblock 0 49 0 log
execute @e[tag=system,scores={tier=1,cd=10,block=70..86}] ~ ~ ~ setblock 0 49 0 stone 5
execute @e[tag=system,scores={tier=1,cd=10,block=87..100}] ~ ~ ~ setblock 0 49 0 dirt
execute @e[tag=system,scores={tier=1,cd=10}] ~ ~ ~ scoreboard players reset @e[tag=system] air
execute @e[tag=system,scores={tier=1,cd=10}] ~ ~ ~ scoreboard objectives remove poindisplay
execute @e[tag=system,scores={tier=1,cd=10}] ~ ~ ~ particle minecraft:basic_smoke_particle 0 50 0
execute @e[tag=system,scores={tier=1,cd=10}] ~ ~ ~ playsound dig.snow @a 0 50 0
execute @e[tag=system,scores={tier=1,cd=10}] ~ ~ ~ scoreboard players add @p[x=0,y=50,z=0,r=6] poin 1
execute @e[tag=system,scores={tier=1,cd=10}] ~ ~ ~ scoreboard players set @e[tag=system] cd 0

execute @e[tag=system,scores={tier=2,air=1}] ~ ~ ~ scoreboard players add @e[tag=system] cd 0
execute @e[tag=system,scores={tier=2,air=1}] ~ ~ ~ scoreboard players add @e[tag=system,scores={cd=..9}] cd 1
execute @e[tag=system,scores={tier=2,air=1}] ~ ~ ~ scoreboard players random @e[tag=system] block 1 100
execute @e[tag=system,scores={tier=2,air=1}] ~ ~ ~ fill 0 49 0 0 49 0 barrier 0 replace air
execute @e[tag=system,scores={tier=2,cd=9,block=1..15}] ~ ~ ~ setblock 0 49 0 cobblestone
execute @e[tag=system,scores={tier=2,cd=9,block=16..32}] ~ ~ ~ setblock 0 49 0 stone 3
execute @e[tag=system,scores={tier=2,cd=9,block=33..48}] ~ ~ ~ setblock 0 49 0 stone 1
execute @e[tag=system,scores={tier=2,cd=9,block=49..54}] ~ ~ ~ setblock 0 49 0 coal_ore
execute @e[tag=system,scores={tier=2,cd=9,block=55..57}] ~ ~ ~ setblock 0 49 0 iron_ore
execute @e[tag=system,scores={tier=2,cd=9,block=58..68}] ~ ~ ~ setblock 0 49 0 log
execute @e[tag=system,scores={tier=2,cd=9,block=69..85}] ~ ~ ~ setblock 0 49 0 stone 5
execute @e[tag=system,scores={tier=2,cd=9,block=86..100}] ~ ~ ~ setblock 0 49 0 dirt
execute @e[tag=system,scores={tier=2,cd=9}] ~ ~ ~ scoreboard players reset @e[tag=system] air
execute @e[tag=system,scores={tier=2,cd=9}] ~ ~ ~ scoreboard objectives remove poindisplay
execute @e[tag=system,scores={tier=2,cd=9}] ~ ~ ~ particle minecraft:basic_smoke_particle 0 50 0
execute @e[tag=system,scores={tier=2,cd=9}] ~ ~ ~ playsound dig.snow @a 0 50 0
execute @e[tag=system,scores={tier=2,cd=9}] ~ ~ ~ scoreboard players add @p[x=0,y=50,z=0,r=6] poin 1
execute @e[tag=system,scores={tier=2,cd=9}] ~ ~ ~ scoreboard players set @e[tag=system] cd 0

execute @e[tag=system,scores={tier=3,air=1}] ~ ~ ~ scoreboard players add @e[tag=system] cd 0
execute @e[tag=system,scores={tier=3,air=1}] ~ ~ ~ scoreboard players add @e[tag=system,scores={cd=..9}] cd 1
execute @e[tag=system,scores={tier=3,air=1}] ~ ~ ~ scoreboard players random @e[tag=system] block 1 125
execute @e[tag=system,scores={tier=3,air=1}] ~ ~ ~ fill 0 49 0 0 49 0 barrier 0 replace air
execute @e[tag=system,scores={tier=3,cd=9,block=1..15}] ~ ~ ~ setblock 0 49 0 cobblestone
execute @e[tag=system,scores={tier=3,cd=9,block=16..32}] ~ ~ ~ setblock 0 49 0 stone 3
execute @e[tag=system,scores={tier=3,cd=9,block=33..48}] ~ ~ ~ setblock 0 49 0 stone 1
execute @e[tag=system,scores={tier=3,cd=9,block=49..54}] ~ ~ ~ setblock 0 49 0 coal_ore
execute @e[tag=system,scores={tier=3,cd=9,block=55..57}] ~ ~ ~ setblock 0 49 0 iron_ore
execute @e[tag=system,scores={tier=3,cd=9,block=58..68}] ~ ~ ~ setblock 0 49 0 log
execute @e[tag=system,scores={tier=3,cd=9,block=69..85}] ~ ~ ~ setblock 0 49 0 stone 5
execute @e[tag=system,scores={tier=3,cd=9,block=86..100}] ~ ~ ~ setblock 0 49 0 dirt
execute @e[tag=system,scores={tier=3,cd=9,block=100..102}] ~ ~ ~ setblock 0 49 0 diamond_ore
execute @e[tag=system,scores={tier=3,cd=9,block=103..112}] ~ ~ ~ setblock 0 49 0 sand
execute @e[tag=system,scores={tier=3,cd=9,block=113..125}] ~ ~ ~ setblock 0 49 0 gravel
execute @e[tag=system,scores={tier=3,cd=9}] ~ ~ ~ scoreboard players reset @e[tag=system] air
execute @e[tag=system,scores={tier=3,cd=9}] ~ ~ ~ scoreboard objectives remove poindisplay
execute @e[tag=system,scores={tier=3,cd=9}] ~ ~ ~ particle minecraft:basic_smoke_particle 0 50 0
execute @e[tag=system,scores={tier=3,cd=9}] ~ ~ ~ playsound dig.snow @a 0 50 0
execute @e[tag=system,scores={tier=3,cd=9}] ~ ~ ~ scoreboard players add @p[x=0,y=50,z=0,r=6] poin 1
execute @e[tag=system,scores={tier=3,cd=9}] ~ ~ ~ scoreboard players set @e[tag=system] cd 0

execute @e[tag=system,scores={tier=4,air=1}] ~ ~ ~ scoreboard players add @e[tag=system] cd 0
execute @e[tag=system,scores={tier=4,air=1}] ~ ~ ~ scoreboard players add @e[tag=system,scores={cd=..9}] cd 1
execute @e[tag=system,scores={tier=4,air=1}] ~ ~ ~ scoreboard players random @e[tag=system] block 1 130
execute @e[tag=system,scores={tier=4,air=1}] ~ ~ ~ fill 0 49 0 0 49 0 barrier 0 replace air
execute @e[tag=system,scores={tier=4,cd=9,block=1..15}] ~ ~ ~ setblock 0 49 0 cobblestone
execute @e[tag=system,scores={tier=4,cd=9,block=16..32}] ~ ~ ~ setblock 0 49 0 stone 3
execute @e[tag=system,scores={tier=4,cd=9,block=33..48}] ~ ~ ~ setblock 0 49 0 stone 1
execute @e[tag=system,scores={tier=4,cd=9,block=49..54}] ~ ~ ~ setblock 0 49 0 coal_ore
execute @e[tag=system,scores={tier=4,cd=9,block=55..57}] ~ ~ ~ setblock 0 49 0 iron_ore
execute @e[tag=system,scores={tier=4,cd=9,block=58..68}] ~ ~ ~ setblock 0 49 0 log
execute @e[tag=system,scores={tier=4,cd=9,block=69..85}] ~ ~ ~ setblock 0 49 0 stone 5
execute @e[tag=system,scores={tier=4,cd=9,block=86..100}] ~ ~ ~ setblock 0 49 0 dirt
execute @e[tag=system,scores={tier=4,cd=9,block=100..104}] ~ ~ ~ setblock 0 49 0 diamond_ore
execute @e[tag=system,scores={tier=4,cd=9,block=105..115}] ~ ~ ~ setblock 0 49 0 sand
execute @e[tag=system,scores={tier=4,cd=9,block=116..125}] ~ ~ ~ setblock 0 49 0 gravel
execute @e[tag=system,scores={tier=4,cd=9,block=126..130}] ~ ~ ~ setblock 0 49 0 lapis_ore
execute @e[tag=system,scores={tier=4,cd=9}] ~ ~ ~ scoreboard players reset @e[tag=system] air
execute @e[tag=system,scores={tier=4,cd=9}] ~ ~ ~ scoreboard objectives remove poindisplay
execute @e[tag=system,scores={tier=4,cd=9}] ~ ~ ~ particle minecraft:basic_smoke_particle 0 50 0
execute @e[tag=system,scores={tier=4,cd=9}] ~ ~ ~ playsound dig.snow @a 0 50 0
execute @e[tag=system,scores={tier=4,cd=9}] ~ ~ ~ scoreboard players add @p[x=0,y=50,z=0,r=6] poin 1
execute @e[tag=system,scores={tier=4,cd=9}] ~ ~ ~ scoreboard players set @e[tag=system] cd 0
